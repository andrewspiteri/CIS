---
title: "cis api validate"
type: manual
status: Active
owner: "Andrew Spiteri"
last_reviewed: "2026-08-14"
review_cadence: "on command change"
cis:
  stable_id: change-impact-studio:manual:cis-api-validate
---

# `cis api validate`

Enforces repository `API-*` rules across source, API rows, OpenAPI, permissions,
Problem Details, lifecycle, rate limits, versions, and public caching.

```text
cis api validate [--repo <path>] [--strict] [--no-refresh] [--format <human|json|agent>]
```

Validation refreshes discovery by default. `--no-refresh` uses existing local state and
fails with `CIS-API-STATE-001` when no normalized operation state has been built.
`--strict` promotes warnings to exit `5`; errors always produce exit `5`. Every diagnostic
contains a stable code, governing rule, evidence, and suggested remediation.

For `public` operations validation requires a governed cache, an indirect background or
precomputed population path, and no direct endpoint persistence evidence—including on
cache miss. Derived diagnostics live under `.cis/local/api/diagnostics.json`.
