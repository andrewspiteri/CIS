---
title: "cis brd reconcile"
type: command-reference
status: Active
owner: "Andrew Spiteri"
last_reviewed: "2026-08-09"
review_cadence: "on command change"
cis:
  stable_id: change-impact-studio:manual:cis-brd-reconcile
---

# `cis brd reconcile`

Reconciles new or changed BRD and development feature-specification evidence into the
canonical BRD review workflow. It requires an existing canonical BRD; use `brd init`
for initial creation.

## Synopsis

```text
cis brd reconcile [--workspace <path>] [--format <human|json|agent>]
```

The command refreshes participant graph baselines and the managed source-assessment
table. New or changed feature specifications enter as `Unreviewed`. Unchanged
assessments and all human-authored BRD sections are preserved. Any evidence change
sets the document to `Review Required` and clears prior approval.

Reconciliation does not claim semantic absorption. A human must disposition each
source. When a feature specification is `Adopted`, its business intent must be
incorporated into the relevant BRD sections and its managed `BRD-SRC-*` ID must appear
in the Traceability section before validation succeeds.

## Development workflow

1. Generate or update a feature specification with front matter
   `type: feature-specification`.
2. Rebuild the affected repository graph.
3. Run `cis brd status`, then `cis brd reconcile` when evidence is unresolved.
4. Review the evidence, update the BRD, and record source traceability.
5. Validate and request explicit human re-approval.

## Exit codes

| Code | Meaning |
| ---: | --- |
| `0` | Evidence reconciled or already unchanged. |
| `2` | Workspace, authority, or graph evidence is invalid. |
| `4` | The canonical BRD is missing. |
| `5` | The reconciled BRD still has review gaps. |

## Related commands

- [`cis brd discover`](cis_brd_discover.md)
- [`cis brd validate`](cis_brd_validate.md)
- [`cis brd approve`](cis_brd_approve.md)
