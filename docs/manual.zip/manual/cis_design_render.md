---
title: "cis design render"
type: command-reference
status: Active
owner: "Andrew Spiteri"
last_reviewed: "2026-08-13"
review_cadence: "on command change"
cis:
  stable_id: change-impact-studio:manual:cis-design-render
---

# `cis design render`

Runs the canonical Sharp/SVG renderer and creates the PNG review pack.

```text
cis design render <change-id> [--repo <path>] [--format <human|json|agent>]
```

Static validation runs first. CIS records Node, Sharp, and libvips versions plus each
PNG path, dimensions, bytes, and SHA-256 hash. Success sets `gate_status` to
`PausedForReview`; all non-review work must stop until explicit design approval.

