---
title: "cis design wireframe-approve"
type: command-reference
status: Active
owner: "Andrew Spiteri"
last_reviewed: "2026-08-13"
review_cadence: "on command change"
cis:
  stable_id: change-impact-studio:manual:cis-design-wireframe-approve
---

# `cis design wireframe-approve`

Records explicit human approval of textual screen behavior and navigation paths.

```text
cis design wireframe-approve <change-id> --reviewer <identity> --reason <rationale> [--repo <path>] [--format <human|json|agent>]
```

Approval is blocked by TODOs, an empty screen inventory, or screens without concrete
routes. CIS records a digest that excludes the approval section so the decision itself
does not change the approved content hash.

