---
title: "cis plan import-spec"
type: command-reference
status: Active
owner: "Andrew Spiteri"
last_reviewed: "2026-08-09"
review_cadence: "on command change"
cis:
  stable_id: change-impact-studio:manual:cis-plan-import-spec
---

# `cis plan import-spec`

In a workspace authority, import is blocked unless `cis technical-intent status` reports
Active and current.

Imports a canonical feature specification into an existing reviewed change and builds
a PARR-style, complexity-bounded issue pack rather than only a summary table.

```text
cis plan import-spec <change-id> --file <repo-relative-spec.md> [--repo <path>] [--format <human|json|agent>]
```

The Markdown source must be inside the repository and outside `.cis/local`. CIS accepts
its native `type: feature-specification` contract and PARR-compatible
`type: specification` documents with a feature title. Intake supports either:

- an `ID`, optional `Surface`, `Requirement`, and `Acceptance criteria` table; or
- a rich narrative specification with a numbered Goals section.

Narrative goals receive stable derived `GOAL-NNN` IDs. Front matter `targets`, `stack`,
and `references` are preserved as task-pack provenance. Recommended rich sections cover
non-goals, workflows and states, model/data/migrations, API and permissions, UX,
integrations, product-specific extensions such as search/retrieval,
lifecycle/carry-forward, security, and testing.

IDs must be unique and every row must replace TODO and placeholder content. CIS keeps
the source Markdown canonical and records its repository-relative path and SHA-256
digest in `plan.md`; it does not create a competing copy.

The command requires planning-ready, human-reviewed impact findings. It writes the
dependency ledger to `plan.md` and one durable Markdown task per workstream under
`agent-tasks/`. Workstreams are created only when the specification requires them:

- parent coordination and scope guard;
- wireframes followed by visual/interaction design and explicit approval;
- documentation, security/permissions, data, schema migration, and backfill;
- API contracts, backend behavior, approved frontend implementation, and integrations;
- infrastructure, observability, lifecycle, and rollout where signalled;
- deterministic verification and independent assurance; and
- final delivery reconciliation and handoff.

Every UI-bearing requirement should include a `Frontend type` column with exactly
`public`, `customer`, or `backoffice`. CIS creates a separate matched wireframe,
design, and frontend implementation task for each affected type. Legacy specifications
without the column are inferred from explicit public/backoffice language and otherwise
treated as customer-facing.

When the specification identifies a public/anonymous/unauthenticated endpoint, CIS
also creates or activates Security, API contract, Backend, Observability, Verification,
and Independent assurance tasks containing `PUBLIC-ENDPOINT-CACHE`. These tasks require
a governed cache response path and prohibit direct database/repository access from the
route/controller/handler, including on cache miss. The detailed policy is seeded as
`specs/public-endpoint-caching-policy-spec.md`.

Search/projection is not a CIS core task type. A product module may register it through
`ICisTaskTypeProvider`; the imported source remains the evidence for applicability.

Every task document contains its objective, required changes extracted from relevant
specification sections, constraints and non-goals, accepted graph evidence, dependencies,
approval gates, acceptance checklist, targeted validation, completion-evidence table,
and explicit deferral/residual-risk section. Task documents are catalogued canonical
records. `design.md` records screen artifacts and human approval; `verification.md`
aggregates exact commands, artifacts, results, blockers, and assurance evidence.

Each item records its stable task-type key/version and is classified `low`, `medium`,
or `high`. A high item is stored only as a `decomposed` parent and must have at least
two bounded low- or medium-complexity children before validation can pass.

For frontend work, `coordination -> wireframe approval -> design approval -> every
downstream task` is required. A rendered design sets a global pause: no implementation,
verification, or delivery task may start until the exact renderer and PNG manifest are
approved. Plan approval does not satisfy either design gate.

Repeating the command against unchanged source and impact state returns `unchanged`.
An approved plan cannot be rebuilt or replaced. Plan approval remains an explicit
human action through `cis plan approve`.

Exit `0` means the import and resulting plan are valid. Exit `5` means a plan was
created but an approval gate remains. Exit `2` means the source, change, or request is
invalid.
