---
title: "cis plan task transition"
type: command-reference
status: Active
owner: "Andrew Spiteri"
last_reviewed: "2026-08-13"
review_cadence: "on command change"
cis:
  stable_id: change-impact-studio:manual:cis-plan-task-transition
---

# `cis plan task transition`

Moves one generated task through its governed lifecycle.

```text
cis plan task transition <change-id> <task-id> --status <status> --actor <identity> --reason <rationale> [--repo <path>] [--format <human|json|agent>]
```

Supported states are Draft, ReadyForReview, Approved, InProgress, Blocked, Deferred,
Complete, Cancelled, and Decomposed. Invalid transitions fail. Completion requires
resolved checklists and evidence. For UI-bearing plans, all downstream work is blocked
until `design.md` has `gate_status: Approved`. Every transition appends an audit event.
Completion also snapshots sanitized CLI-usage counts, failures, possible token savings,
and a ledger digest into the task and `verification.md` when local usage exists.
