---
title: "cis verify compare"
type: command-reference
status: Active
owner: "Andrew Spiteri"
last_reviewed: "2026-08-14"
review_cadence: "on command change"
cis:
  stable_id: change-impact-studio:manual:cis-verify-compare
---

# `cis verify compare`

Compare planned task targets with observed changed files.

```text
cis verify compare <change-id> [--repo <path>] [--format <human|json|agent>]
```

Reports planned-but-missing and unplanned changes without rewriting the plan.
