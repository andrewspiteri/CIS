---
title: "cis verify diff"
type: command-reference
status: Active
owner: "Andrew Spiteri"
last_reviewed: "2026-08-14"
review_cadence: "on command change"
cis:
  stable_id: change-impact-studio:manual:cis-verify-diff
---

# `cis verify diff`

Capture changed files from a change dossier Git baseline.

```text
cis verify diff <change-id> [--repo <path>] [--format <human|json|agent>]
```

The snapshot lives under `.cis/local/verify/` and is not acceptance.
