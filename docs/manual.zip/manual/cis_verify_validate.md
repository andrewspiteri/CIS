---
title: "cis verify validate"
type: command-reference
status: Active
owner: "Andrew Spiteri"
last_reviewed: "2026-08-14"
review_cadence: "on command change"
cis:
  stable_id: change-impact-studio:manual:cis-verify-validate
---

# `cis verify validate`

Validate plan, design, task, and verification evidence gates.

```text
cis verify validate <change-id> [--repo <path>] [--format <human|json|agent>]
```

Errors block final verification acceptance.
